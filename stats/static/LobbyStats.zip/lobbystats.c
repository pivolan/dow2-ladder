// LobbyStats.dll — рейтинг Relic прямо в лобби DoW2 Retribution / Elite.
//
// Как работает: перехватываем вызов движка «вызвать функцию Flash» (FUN_0045db6c, __thiscall
// Invoke(method, flags, GFxValue* args, count)). Когда движок отправляет в ролик лобби
// Receive_PopulatePlayerList, в каждом слоте игрока дописываем рейтинг к нику и подменяем
// всплывающую подсказку слота (поле m_tooltip) на «рейтинг / победы / игры / часы».
// Данные берёт фоновый поток с https://rts.fintebtc.de/stats/api/lobby (публичный API Relic).
// Первый показ ника — без цифр; они появятся при следующем обновлении лобби (вход, готовность,
// смена расы) и сразу в следующих лобби (кэш на диске рядом с DLL).
//
// Подходит только к DOW2.exe 3.19 (Steam): перед установкой проверяем байты пролога.
#include <windows.h>
#include <winhttp.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <ctype.h>

#define HOOK_ADDR   0x0045DB6C
#define HOOK_RESUME 0x0045DB71
static const unsigned char PROLOGUE[5] = {0xB8, 0x59, 0x70, 0xEF, 0x00};   // mov eax, 0x00EF7059

#define SERVER_HOST L"rts.fintebtc.de"
#define SERVER_PATH "/stats/api/lobby"

// GFxValue Scaleform 3.x: 16 байт. Тип в первом слове, значение с +8.
typedef struct { int type; int pad; union { double num; unsigned char b; const wchar_t *ws; const char *s; } v; } GFxValue;
enum { GFX_BOOL = 2, GFX_NUMBER = 3, GFX_STRING = 4, GFX_WSTRING = 5 };
enum { HEADER_ARGS = 5, SLOT_ARGS = 20, A_HASUSER = 0, A_SLOTTYPE = 4, A_NAME = 5, A_TOOLTIP = 19 };
enum { SLOT_LOCAL = 0, SLOT_REMOTE = 1 };

typedef struct { wchar_t name[64]; int known; int rating, wins, losses, hours; DWORD fetched; } Entry;
#define MAX_ENTRIES 256
static Entry g_cache[MAX_ENTRIES]; static int g_ncache;
static CRITICAL_SECTION g_lock; static HANDLE g_wake;
static wchar_t g_pending[16][64]; static int g_npending;
static wchar_t g_dir[MAX_PATH];
static int g_showInName = 1;

static void logmsg(const char *fmt, ...) {
    wchar_t p[MAX_PATH]; _snwprintf(p, MAX_PATH, L"%lsLobbyStats.log", g_dir);
    FILE *f = _wfopen(p, L"a"); if (!f) return;
    SYSTEMTIME t; GetLocalTime(&t); fprintf(f, "%02d:%02d:%02d ", t.wHour, t.wMinute, t.wSecond);
    va_list a; va_start(a, fmt); vfprintf(f, fmt, a); va_end(a); fputc('\n', f); fclose(f);
}

static Entry *find(const wchar_t *name) {
    for (int i = 0; i < g_ncache; i++) if (!wcscmp(g_cache[i].name, name)) return &g_cache[i];
    return NULL;
}
static Entry *find_or_add(const wchar_t *name) {
    Entry *e = find(name); if (e) return e;
    if (g_ncache == MAX_ENTRIES) { memmove(g_cache, g_cache + 1, sizeof(Entry) * (MAX_ENTRIES - 1)); g_ncache--; }
    e = &g_cache[g_ncache++]; memset(e, 0, sizeof *e); wcsncpy(e->name, name, 63); return e;
}

// ---------- кэш на диске: строки «ник\tрейтинг\tпобеды\tпоражения\tчасы» в UTF-8 ----------
static void cache_path(wchar_t *p) { _snwprintf(p, MAX_PATH, L"%lsLobbyStats.cache", g_dir); }
static void parse_lines(char *buf, int from_disk) {
    for (char *line = strtok(buf, "\n"); line; line = strtok(NULL, "\n")) {
        char *f[6] = {0}; int n = 0; char *p = line;
        while (n < 6) { f[n++] = p; p = strchr(p, '\t'); if (!p) break; *p++ = 0; }
        if (n < 2 || !*f[0]) continue;
        wchar_t name[64]; if (!MultiByteToWideChar(CP_UTF8, 0, f[0], -1, name, 64)) continue;
        Entry *e = find_or_add(name);
        e->fetched = from_disk ? 0 : GetTickCount();
        if (n >= 4 && strcmp(f[1], "-")) {
            e->known = 1; e->rating = atoi(f[1]); e->wins = atoi(f[2]); e->losses = atoi(f[3]);
            e->hours = (n >= 5 && strcmp(f[4], "-")) ? atoi(f[4]) : -1;
        } else if (!from_disk) e->known = 0;
    }
}
static void load_cache(void) {
    wchar_t p[MAX_PATH]; cache_path(p); FILE *f = _wfopen(p, L"rb"); if (!f) return;
    static char buf[64 * 1024]; size_t n = fread(buf, 1, sizeof buf - 1, f); fclose(f); buf[n] = 0;
    parse_lines(buf, 1);
}
static void save_cache(void) {
    wchar_t p[MAX_PATH]; cache_path(p); FILE *f = _wfopen(p, L"wb"); if (!f) return;
    for (int i = 0; i < g_ncache; i++) if (g_cache[i].known) {
        char name[256]; WideCharToMultiByte(CP_UTF8, 0, g_cache[i].name, -1, name, sizeof name, NULL, NULL);
        fprintf(f, "%s\t%d\t%d\t%d\t%d\n", name, g_cache[i].rating, g_cache[i].wins, g_cache[i].losses, g_cache[i].hours);
    }
    fclose(f);
}

// ---------- сеть ----------
static void urlenc(const wchar_t *w, char *out, int cap) {
    char u[256]; WideCharToMultiByte(CP_UTF8, 0, w, -1, u, sizeof u, NULL, NULL);
    int o = 0;
    for (unsigned char *c = (unsigned char *)u; *c && o < cap - 4; c++) {
        if (isalnum(*c) || strchr("-_.~", *c)) out[o++] = *c;
        else o += sprintf(out + o, "%%%02X", *c);
    }
    out[o] = 0;
}
static int http_get(const char *pathq, char *out, int cap) {
    int got = 0; wchar_t wpath[4096]; MultiByteToWideChar(CP_UTF8, 0, pathq, -1, wpath, 4096);
    HINTERNET s = WinHttpOpen(L"LobbyStats/1.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, NULL, NULL, 0);
    if (!s) return -1;
    WinHttpSetTimeouts(s, 5000, 5000, 15000, 30000);
    HINTERNET c = WinHttpConnect(s, SERVER_HOST, INTERNET_DEFAULT_HTTPS_PORT, 0);
    HINTERNET r = c ? WinHttpOpenRequest(c, L"GET", wpath, NULL, NULL, NULL, WINHTTP_FLAG_SECURE) : NULL;
    if (r && WinHttpSendRequest(r, NULL, 0, NULL, 0, 0, 0) && WinHttpReceiveResponse(r, NULL)) {
        DWORD n;
        while (got < cap - 1 && WinHttpReadData(r, out + got, cap - 1 - got, &n) && n) got += n;
    } else got = -1;
    if (got >= 0) out[got] = 0;
    if (r) WinHttpCloseHandle(r); if (c) WinHttpCloseHandle(c); WinHttpCloseHandle(s);
    return got;
}
static DWORD WINAPI worker(LPVOID _) {
    static char resp[64 * 1024], q[4096];
    for (;;) {
        WaitForSingleObject(g_wake, INFINITE);
        Sleep(300);                                  // собираем все ники одного обновления лобби в один запрос
        wchar_t names[16][64]; int n;
        EnterCriticalSection(&g_lock);
        n = g_npending; memcpy(names, g_pending, sizeof(wchar_t) * 64 * n); g_npending = 0;
        LeaveCriticalSection(&g_lock);
        if (!n) continue;
        int o = sprintf(q, "%s?", SERVER_PATH);
        for (int i = 0; i < n; i++) { char e[400]; urlenc(names[i], e, sizeof e); o += snprintf(q + o, sizeof q - o, "%sn=%s", i ? "&" : "", e); }
        int got = http_get(q, resp, sizeof resp);
        logmsg("lookup %d names -> %d bytes", n, got);
        EnterCriticalSection(&g_lock);
        if (got > 0) { parse_lines(resp, 0); save_cache(); }
        else for (int i = 0; i < n; i++) find_or_add(names[i])->fetched = GetTickCount();   // не долбим сервер при ошибке
        LeaveCriticalSection(&g_lock);
    }
    return 0;
}

// ---------- перехват ----------
typedef char (__fastcall *InvokeFn)(void *self, void *edx, const char *method, int flags, GFxValue *args, unsigned count);
static InvokeFn g_orig;
static wchar_t g_nameBuf[16][128], g_tipBuf[16][320];

static void decorate(GFxValue *args, unsigned count) {
    if (count < HEADER_ARGS + SLOT_ARGS || (count - HEADER_ARGS) % SLOT_ARGS) {
        static int warned; if (!warned++) logmsg("PopulatePlayerList: unexpected arg count %u, not touching", count);
        return;
    }
    unsigned slots = (count - HEADER_ARGS) / SLOT_ARGS; int want = 0;
    EnterCriticalSection(&g_lock);
    for (unsigned i = 0; i < slots && i < 16; i++) {
        GFxValue *a = args + HEADER_ARGS + i * SLOT_ARGS;
        if (a[A_HASUSER].type != GFX_BOOL || !a[A_HASUSER].v.b) continue;
        if (a[A_SLOTTYPE].type != GFX_NUMBER) continue;
        int st = (int)a[A_SLOTTYPE].v.num;
        if (st != SLOT_LOCAL && st != SLOT_REMOTE) continue;
        if (a[A_NAME].type != GFX_WSTRING || !a[A_NAME].v.ws || !a[A_NAME].v.ws[0]) continue;
        if (a[A_TOOLTIP].type != GFX_WSTRING) continue;          // раскладка не та, что ждём — не трогаем
        const wchar_t *name = a[A_NAME].v.ws;
        Entry *e = find(name);
        DWORD now = GetTickCount();
        if (!e || !e->fetched || now - e->fetched > 10 * 60 * 1000) {          // нет данных или старше 10 минут
            int dup = 0;
            for (int k = 0; k < g_npending; k++) if (!wcscmp(g_pending[k], name)) dup = 1;
            if (!dup && g_npending < 16) { wcsncpy(g_pending[g_npending++], name, 63); want = 1; }
            if (!e) { e = find_or_add(name); e->fetched = 0; }
        }
        if (!e->known) continue;
        int games = e->wins + e->losses, wr = games ? (e->wins * 100 + games / 2) / games : 0;
        if (g_showInName) {
            _snwprintf(g_nameBuf[i], 127, L"%ls  [%d]", name, e->rating); g_nameBuf[i][127] = 0;
            a[A_NAME].v.ws = g_nameBuf[i];
        }
        wchar_t hours[48] = L"";
        if (e->hours >= 0) _snwprintf(hours, 47, L"\nSteam hours: %d", e->hours);
        _snwprintf(g_tipBuf[i], 319, L"%ls\nRelic rating: %d\nWin rate: %d%%  (%d W / %d L)\nGames: %d%ls",
                   name, e->rating, wr, e->wins, e->losses, games, hours);
        g_tipBuf[i][319] = 0;
        a[A_TOOLTIP].type = GFX_WSTRING; a[A_TOOLTIP].v.ws = g_tipBuf[i];
    }
    LeaveCriticalSection(&g_lock);
    if (want) SetEvent(g_wake);
}

static char __fastcall hook(void *self, void *edx, const char *method, int flags, GFxValue *args, unsigned count) {
    if (method && args && !strcmp(method, "Receive_PopulatePlayerList")) {
        if (count < 4096 && !IsBadReadPtr(args, count * sizeof(GFxValue))) decorate(args, count);
    }
    return g_orig(self, edx, method, flags, args, count);
}

static void install(void) {
    unsigned char *target = (unsigned char *)HOOK_ADDR;
    if (IsBadReadPtr(target, 5) || memcmp(target, PROLOGUE, 5)) { logmsg("DOW2.exe version mismatch at %08X, not hooking", HOOK_ADDR); return; }
    unsigned char *tr = VirtualAlloc(NULL, 16, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    memcpy(tr, PROLOGUE, 5); tr[5] = 0xE9; *(DWORD *)(tr + 6) = HOOK_RESUME - (DWORD)(tr + 10);
    g_orig = (InvokeFn)tr;
    DWORD old; VirtualProtect(target, 5, PAGE_EXECUTE_READWRITE, &old);
    target[0] = 0xE9; *(DWORD *)(target + 1) = (DWORD)hook - (DWORD)(target + 5);
    VirtualProtect(target, 5, old, &old); FlushInstructionCache(GetCurrentProcess(), target, 5);
    logmsg("hooked Invoke at %08X", HOOK_ADDR);
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID _) {
    if (reason != DLL_PROCESS_ATTACH) return TRUE;
    DisableThreadLibraryCalls(h);
    GetModuleFileNameW(h, g_dir, MAX_PATH); wchar_t *sl = wcsrchr(g_dir, L'\\'); if (sl) sl[1] = 0; else g_dir[0] = 0;
    wchar_t ini[MAX_PATH]; _snwprintf(ini, MAX_PATH, L"%lsLobbyStats.ini", g_dir);
    g_showInName = GetPrivateProfileIntW(L"LobbyStats", L"ShowRatingInName", 1, ini);
    InitializeCriticalSection(&g_lock); g_wake = CreateEventW(NULL, FALSE, FALSE, NULL);
    load_cache(); install();
    CloseHandle(CreateThread(NULL, 0, worker, NULL, 0, NULL));
    return TRUE;
}

// для проверки вне игры: прогнать подмену на поддельном наборе аргументов
__declspec(dllexport) int LobbyStats_Test(GFxValue *args, unsigned count) { decorate(args, count); return g_ncache; }
__declspec(dllexport) void LobbyStats_Lookup(const wchar_t *name) {
    EnterCriticalSection(&g_lock); wcsncpy(g_pending[g_npending++], name, 63); LeaveCriticalSection(&g_lock); SetEvent(g_wake);
}
