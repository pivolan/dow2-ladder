LobbyStats.dll - Relic rating in the Dawn of War II Retribution / Elite lobby  (prototype, 21.10.2026)

What it does
  In the game lobby each player's name gets the Relic rating appended:  pivolan  [2087]
  Hover a player slot to see a tooltip: Relic rating, win rate (wins / losses), games, Steam hours.
  Data: https://rts.fintebtc.de/stats/ (public Relic API, the same rating Relic computes for every online game).
  The first time a name appears it is shown without numbers; they appear on the next lobby update
  (someone joins, readies, changes race) and instantly in later lobbies (cache file next to the DLL).

Install (Elite)
  1. Copy LobbyStats.dll to  <Steam>\steamapps\common\Dawn of War II - Retribution\Elite_DLLs\
  2. Open Elite.launchconfig (same game folder) in Notepad and append LobbyStats.dll to InjectedFiles:
       InjectedFiles=CullspherePatch.dll, DoW2_ArmyPainterFix.dll, MiscFixes.dll, ShellPatch.dll, LobbyStats.dll
  3. Start Elite as usual.
  Check: Elite_DLLs\LobbyStats.log should contain "hooked Invoke at 0045DB6C" and later "lookup N names".
  Only DOW2.exe 3.19 (current Steam build) is supported; on any other build the DLL does nothing and says so in the log.

Options (optional file Elite_DLLs\LobbyStats.ini)
  [LobbyStats]
  ShowRatingInName=0     ; keep names untouched, show the rating only in the hover tooltip

Remove: delete LobbyStats.dll and remove it from InjectedFiles.

---------------------------------------------------------------------------------------------
Русский

Что делает: в лобби к нику игрока дописывается рейтинг Relic (pivolan  [2087]); при наведении на слот —
подсказка: рейтинг, доля побед (победы / поражения), число игр, часы в Steam.
Цифры появляются при следующем обновлении лобби (кто-то зашёл, нажал «готов», сменил расу), дальше — сразу из кэша.

Установка: скопировать LobbyStats.dll в папку игры Elite_DLLs\, в Elite.launchconfig дописать
", LobbyStats.dll" в конец строки InjectedFiles, запустить Elite. Проверка — файл Elite_DLLs\LobbyStats.log.
Только рейтинг во всплывающей подсказке, без изменения ников: файл LobbyStats.ini с [LobbyStats] ShowRatingInName=0.
