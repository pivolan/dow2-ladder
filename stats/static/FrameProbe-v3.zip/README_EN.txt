FrameProbe.dll v3 - diagnostic logger for Dawn of War II: Retribution (Elite). It does not change the game, it only writes logs.

Install: put FrameProbe.dll into <game folder>\Elite_DLLs\ and add ", FrameProbe.dll" to the end of the InjectedFiles line in Elite.launchconfig.

Observer lag: watch a replay for ~1 minute, then spectate a live multiplayer game for 1-2 minutes. Note the times and FPS.
Continue button: play a multiplayer match to the end and stay on the score screen for ~30 seconds (host and one more player if possible).

Then send Elite_DLLs\FrameProbe.log and Elite_DLLs\FrameProbe_trace.log.
Remove: delete ", FrameProbe.dll" from InjectedFiles and delete the file.
